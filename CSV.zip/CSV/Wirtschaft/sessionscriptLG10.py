# Lese diese Dateien ein
# - Erwerbstaetige1
# - Konsumentwicklung
# - Lohnentwicklung

# Bilde diese Ratios:
# Anteil der Land-, Forst- und Fischereiarbeiter sowie der Dienstleister an den Gesamtbeschäftigten.
# Anteil der Wohn- sowie der Lebenserhaltungskosten (Nahrung/Genuss) am Gesamtkonsum.
# Verhältnis von Netto- zu Bruttolöhnen. 
# 
# Schreibe diese Ratios in eine CSV- Datei zurück. 

import csv


